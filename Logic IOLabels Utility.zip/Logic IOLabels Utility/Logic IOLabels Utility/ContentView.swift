//
//  ContentView.swift
//  Logic IOLabels Utility
//
//  Created by Djordjo Micic on 23.03.26.
//

import SwiftUI
import UniformTypeIdentifiers

func displayTypeName(for rawType: String) -> String {
    switch rawType {
    case "type_65": return "Mono Input"
    case "type_73": return "Stereo Input"
    case "type_68": return "Mono Output"
    case "type_76": return "Stereo Output"
    case "type_69": return "Bus"
    default: return rawType
    }
}

func rawTypeName(for displayType: String) -> String? {
    switch displayType.trimmingCharacters(in: .whitespacesAndNewlines) {
    case "Mono Input": return "type_65"
    case "Stereo Input": return "type_73"
    case "Mono Output": return "type_68"
    case "Stereo Output": return "type_76"
    case "Bus": return "type_69"
    default: return nil
    }
}

let realHome = FileManager.default.homeDirectoryForCurrentUser.path

struct ContentView: View {
    @State private var selectedSection: SidebarItem = .home

    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Logic IOLabels")
                    .font(.headline)
                    .padding(.bottom, 12)

                sidebarButton(.home)
                sidebarButton(.backup)
                sidebarButton(.recall)
                sidebarButton(.csvImport)
                sidebarButton(.paths)

                Spacer()
            }
            .padding(16)
            .frame(width: 220)
            .background(Color(nsColor: .windowBackgroundColor))

            Divider()

            Group {
                switch selectedSection {
                case .home:
                    HomeView()
                case .backup:
                    BackupView()
                case .recall:
                    RecallView()
                case .csvImport:
                    CSVImportView()
                case .paths:
                    PathsView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(minWidth: 900, minHeight: 560)
    }

    @ViewBuilder
    func sidebarButton(_ item: SidebarItem) -> some View {
        Button {
            selectedSection = item
        } label: {
            HStack(spacing: 10) {
                Image(systemName: item.icon)
                    .frame(width: 18)
                Text(item.title)
                Spacer()
            }
            .padding(.vertical, 10)
            .padding(.horizontal, 12)
            .background(selectedSection == item ? Color.accentColor.opacity(0.15) : Color.clear)
            .cornerRadius(10)
        }
        .buttonStyle(.plain)
    }
}

enum SidebarItem {
    case home
    case backup
    case recall
    case csvImport
    case paths

    var title: String {
        switch self {
        case .home: return "Home"
        case .backup: return "Backup"
        case .recall: return "Recall"
        case .csvImport: return "CSV Import"
        case .paths: return "Paths"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house"
        case .backup: return "externaldrive.badge.plus"
        case .recall: return "clock.arrow.circlepath"
        case .csvImport: return "tablecells"
        case .paths: return "folder"
        }
    }
}

struct HomeView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            Text("Logic IOLabels Utility")
                .font(.largeTitle)
                .bold()

            Text("Manage Logic Pro IO Labels, create backups, restore saved label sets, and import labels from CSV.")
                .font(.title3)
                .foregroundColor(.secondary)

            VStack(alignment: .leading, spacing: 16) {
                Text("Welcome")
                    .font(.title2)
                    .bold()

                Text("Use this tool to manage the Logic Pro IO label files on your Mac. You can create backups before making changes, restore a previous backup, import labels from CSV, and check the file paths used by the app.")
                    .foregroundColor(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(20)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(16)

            Spacer()
        }
        .padding(30)
    }
}

struct PlaceholderView: View {
    let title: String

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.largeTitle)
                .bold()

            Text("This section will be built next.")
                .foregroundColor(.secondary)

            Spacer()
        }
        .padding(30)
    }
}

#Preview {
    ContentView()
}

struct PathsView: View {
    @AppStorage("LogicIO_PlistPath") private var plistPath: String = NSString(string: "~/Library/Preferences/com.apple.logic10.plist").expandingTildeInPath
    @AppStorage("LogicIO_CSPath") private var csPath: String = NSString(string: "~/Library/Preferences/com.apple.logic.pro.cs").expandingTildeInPath
    @AppStorage("LogicIO_BackupPath") private var backupPath: String = NSString(string: "~/Documents/Logic IOLabels Utility Backups").expandingTildeInPath

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Paths")
                .font(.largeTitle)
                .bold()

            Text("Set file locations and reveal them in Finder.")
                .foregroundColor(.secondary)

            filePathField(title: "Plist path", text: $plistPath)
            filePathField(title: "CS path", text: $csPath)
            folderPathField(title: "Backup folder", text: $backupPath)

            Spacer()
        }
        .padding(30)
    }

    @ViewBuilder
    func filePathField(title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)

            TextField("", text: Binding(
                get: {
                    text.wrappedValue.replacingOccurrences(of: realHome, with: "~")
                },
                set: {
                    text.wrappedValue = $0.replacingOccurrences(of: "~", with: realHome)
                }
            ))
            .textFieldStyle(.roundedBorder)

            HStack {
                Button("Reveal") {
                    revealInFinder(path: text.wrappedValue)
                }

                Button("Choose…") {
                    chooseFile(binding: text)
                }
            }
        }
    }

    @ViewBuilder
    func folderPathField(title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)

            TextField("", text: Binding(
                get: {
                    text.wrappedValue.replacingOccurrences(of: realHome, with: "~")
                },
                set: {
                    text.wrappedValue = $0.replacingOccurrences(of: "~", with: realHome)
                }
            ))
            .textFieldStyle(.roundedBorder)

            HStack {
                Button("Reveal") {
                    revealInFinder(path: text.wrappedValue)
                }

                Button("Choose…") {
                    chooseFolder(binding: text)
                }
            }
        }
    }

    func revealInFinder(path: String) {
        guard !path.isEmpty else { return }
        let url = URL(fileURLWithPath: (path as NSString).expandingTildeInPath)
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    func chooseFile(binding: Binding<String>) {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false

        if panel.runModal() == .OK {
            binding.wrappedValue = panel.url?.path ?? ""
        }
    }

    func chooseFolder(binding: Binding<String>) {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false

        if panel.runModal() == .OK {
            binding.wrappedValue = panel.url?.path ?? ""
        }
    }
}

struct BackupView: View {
    @AppStorage("LogicIO_PlistPath") private var plistPath: String = NSString(string: "~/Library/Preferences/com.apple.logic10.plist").expandingTildeInPath
    @AppStorage("LogicIO_BackupPath") private var backupPath: String = NSString(string: "~/Documents/Logic IOLabels Utility Backups").expandingTildeInPath

    @AppStorage("LogicIO_CSPath") private var csPath: String = NSString(string: "~/Library/Preferences/com.apple.logic.pro.cs").expandingTildeInPath

    @State private var tagName: String = ""
    @State private var includePlist: Bool = true
    @State private var includeCS: Bool = true
    @State private var statusMessage: String = "Ready."

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Backup")
                .font(.largeTitle)
                .bold()

            Text("Create a backup of the current Logic Pro Mixer IO Labels and/ or the controller assignments.")
                .foregroundColor(.secondary)

            VStack(alignment: .leading, spacing: 8) {
                Text("Destination")
                    .font(.headline)

                Text(backupPath.replacingOccurrences(of: realHome, with: "~"))
                    .foregroundColor(.secondary)
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(nsColor: .controlBackgroundColor))
                    .cornerRadius(12)
            }

            VStack(alignment: .leading, spacing: 16) {
                Text("Backup Name")
                    .font(.headline)

                TextField("Optional tag", text: $tagName)
                    .textFieldStyle(.roundedBorder)

                Toggle("Include IO Labels (plist)", isOn: $includePlist)
                Toggle("Include Controller Assignments (CS)", isOn: $includeCS)
            }
            .padding(20)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(16)

            HStack {
                Button("Create Backup") {
                    createBackup()
                }
                .keyboardShortcut(.defaultAction)
            }

            Text(statusMessage)
                .foregroundColor(.secondary)

            Spacer()
        }
        .padding(30)
    }

    func createBackup() {
        let plistURL = URL(fileURLWithPath: (plistPath as NSString).expandingTildeInPath)
        let csURL = URL(fileURLWithPath: (csPath as NSString).expandingTildeInPath)
        let backupRootURL = URL(fileURLWithPath: (backupPath as NSString).expandingTildeInPath)

        if !includePlist && !includeCS {
            statusMessage = "Select at least one file to include."
            return
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let timestamp = formatter.string(from: Date())

        let folderName = tagName.isEmpty ? timestamp : "\(timestamp)_\(tagName)"
        let backupFolderURL = backupRootURL.appendingPathComponent(folderName)

        do {
            try FileManager.default.createDirectory(at: backupFolderURL, withIntermediateDirectories: true)

            if includePlist {
                guard FileManager.default.fileExists(atPath: plistURL.path) else {
                    statusMessage = "Plist not found."
                    return
                }

                let dest = backupFolderURL.appendingPathComponent("com.apple.logic10.plist")
                try FileManager.default.copyItem(at: plistURL, to: dest)
                try exportIOLabelsCSV(from: plistURL, to: backupFolderURL)
            }
            
            

            if includeCS {
                guard FileManager.default.fileExists(atPath: csURL.path) else {
                    statusMessage = "CS file not found."
                    return
                }
                let dest = backupFolderURL.appendingPathComponent("com.apple.logic.pro.cs")
                try FileManager.default.copyItem(at: csURL, to: dest)
            }

            statusMessage = "Backup created: \(folderName)"
        } catch {
            statusMessage = "Backup failed: \(error.localizedDescription)"
        }
    }
    
    func exportIOLabelsCSV(from plistURL: URL, to backupFolderURL: URL) throws {
        let data = try Data(contentsOf: plistURL)

        guard let plistDict = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
              let ioLabelsArray = plistDict["IOLabels"] as? [[String: Any]],
              let firstDevice = ioLabelsArray.first,
              let deviceDict = firstDevice["dev_1"] as? [String: Any] else {
            return
        }

        let allowedTypes = ["type_65", "type_73", "type_68", "type_76", "type_69"]

        var rows: [(type: String, index: Int, name: String)] = []

        for type in allowedTypes {
            guard let typeDict = deviceDict[type] as? [String: Any] else { continue }

            for (indexKey, value) in typeDict {
                guard let index = Int(indexKey),
                      let entry = value as? [String: Any] else { continue }

                let name = (entry["lname"] as? String) ?? ""
                rows.append((type: type, index: index, name: name))
            }
        }

        rows.sort {
            if $0.type == $1.type {
                return $0.index < $1.index
            }
            return $0.type < $1.type
        }

        var csv = "Index,Type,Name\n"
        for row in rows {
            csv += "\(row.index),\(csvEscape(displayTypeName(for: row.type))),\(csvEscape(row.name))\n"
        }

        let csvURL = backupFolderURL.appendingPathComponent("IOLabels.csv")
        try csv.write(to: csvURL, atomically: true, encoding: .utf8)
    }

    func csvEscape(_ text: String) -> String {
        let escaped = text.replacingOccurrences(of: "\"", with: "\"\"")
        return "\"\(escaped)\""
    }
    
    func displayTypeName(for rawType: String) -> String {
        switch rawType {
        case "type_65": return "Mono Input"
        case "type_73": return "Stereo Input"
        case "type_68": return "Mono Output"
        case "type_76": return "Stereo Output"
        case "type_69": return "Bus"
        default: return rawType
        }
    }

    func rawTypeName(for displayType: String) -> String? {
        switch displayType.trimmingCharacters(in: .whitespacesAndNewlines) {
        case "Mono Input": return "type_65"
        case "Stereo Input": return "type_73"
        case "Mono Output": return "type_68"
        case "Stereo Output": return "type_76"
        case "Bus": return "type_69"
        default: return nil
        }
    }
}

struct RecallView: View {
    @AppStorage("LogicIO_PlistPath") private var plistPath: String = NSString(string: "~/Library/Preferences/com.apple.logic10.plist").expandingTildeInPath
    @AppStorage("LogicIO_CSPath") private var csPath: String = NSString(string: "~/Library/Preferences/com.apple.logic.pro.cs").expandingTildeInPath
    @AppStorage("LogicIO_BackupPath") private var backupPath: String = NSString(string: "~/Documents/Logic IOLabels Utility Backups").expandingTildeInPath
    @AppStorage("LogicIO_LastRecallName") private var lastRecallName: String = ""
    @AppStorage("LogicIO_LastRecallDate") private var lastRecallDate: String = ""

    @State private var backups: [URL] = []
    @State private var selectedBackup: URL?
    @State private var recallPlist: Bool = true
    @State private var recallCS: Bool = true
    @State private var statusMessage: String = "Ready."

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Recall")
                .font(.largeTitle)
                .bold()

            Text("Restore a previously created backup.")
                .foregroundColor(.secondary)
            
            if !lastRecallName.isEmpty {
                Text("Last recall: \(lastRecallDate) – \(lastRecallName)")
                    .foregroundColor(.secondary)
            }
            
            VStack(alignment: .leading, spacing: 12) {
                Toggle("Recall IO Labels (plist)", isOn: $recallPlist)
                Toggle("Recall Controller Assignments (CS)", isOn: $recallCS)
            }
            .padding(20)
            .background(Color(nsColor: .controlBackgroundColor))
            .cornerRadius(16)

            HStack {
                Button("Refresh") {
                    loadBackups()
                }

                Button("Recall") {
                    restoreBackup()
                }
                .disabled(selectedBackup == nil)
            }

            List(selection: $selectedBackup) {
                ForEach(backups, id: \.self) { url in
                    Text(url.lastPathComponent)
                        .tag(url as URL?)
                }
            }
            .frame(minHeight: 250)

            Text(statusMessage)
                .foregroundColor(.secondary)

            Spacer()
        }
        .padding(30)
        .onAppear {
            loadBackups()
        }
    }

    func loadBackups() {
        let root = URL(fileURLWithPath: (backupPath as NSString).expandingTildeInPath)

        do {
            let items = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)
            backups = items.filter { $0.hasDirectoryPath }.sorted { $0.lastPathComponent > $1.lastPathComponent }
        } catch {
            statusMessage = "Failed to load backups."
        }
    }

    func restoreBackup() {
        guard let backup = selectedBackup else { return }

        let plistURL = URL(fileURLWithPath: (plistPath as NSString).expandingTildeInPath)
        let csURL = URL(fileURLWithPath: (csPath as NSString).expandingTildeInPath)
        
        var restoredSomething = false
        var missingItems: [String] = []

        let backupPlist = backup.appendingPathComponent("com.apple.logic10.plist")
        let backupCS = backup.appendingPathComponent("com.apple.logic.pro.cs")
        
        if !recallPlist && !recallCS {
            statusMessage = "Select at least one file to recall."
            return
        }

        do {
            if recallPlist {
                if FileManager.default.fileExists(atPath: backupPlist.path) {

                    let currentData = try Data(contentsOf: plistURL)
                    let backupData = try Data(contentsOf: backupPlist)

                    var currentPlist = try PropertyListSerialization.propertyList(from: currentData, format: nil) as! [String: Any]
                    let backupPlistDict = try PropertyListSerialization.propertyList(from: backupData, format: nil) as! [String: Any]

                    if let ioLabels = backupPlistDict["IOLabels"] {
                        currentPlist["IOLabels"] = ioLabels

                        // 👉 THIS is Step 2 (SUCCESS CASE)
                        restoredSomething = true

                    } else {
                        // 👉 backup exists but no IOLabels inside
                        missingItems.append("IO Labels")
                    }

                    let newData = try PropertyListSerialization.data(fromPropertyList: currentPlist, format: .xml, options: 0)
                    try newData.write(to: plistURL)

                } else {
                    // 👉 THIS is Step 2 (FILE MISSING CASE)
                    missingItems.append("IO Labels")
                }
            }

            if recallCS {
                if FileManager.default.fileExists(atPath: backupCS.path) {
                    try FileManager.default.removeItem(at: csURL)
                    try FileManager.default.copyItem(at: backupCS, to: csURL)

                    restoredSomething = true
                } else {
                    missingItems.append("Controller Assignments")
                }
            }
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            lastRecallDate = formatter.string(from: Date())
            lastRecallName = backup.lastPathComponent
            
            if restoredSomething {
                if missingItems.isEmpty {
                    statusMessage = "Recall completed: \(backup.lastPathComponent)"
                } else {
                    statusMessage = "Recall completed with missing items: \(missingItems.joined(separator: ", "))."
                }
            } else {
                statusMessage = "Nothing recalled. Missing: \(missingItems.joined(separator: ", "))."
            }
        } catch {
            statusMessage = "Recall failed: \(error.localizedDescription)"
        }
    }
}

struct CSVImportView: View {
    @AppStorage("LogicIO_PlistPath") private var plistPath: String = NSString(string: "~/Library/Preferences/com.apple.logic10.plist").expandingTildeInPath
    @AppStorage("LogicIO_LastCSVFolderBookmark") private var lastCSVFolderBookmark: Data = Data()

    @State private var statusMessage: String = "Ready."
    @State private var previewRows: [[String: String]] = []
    @State private var pendingIOLabels: [String: Any]? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("CSV Import")
                .font(.largeTitle)
                .bold()

            Text("Import IO Labels from a CSV file into the current Logic plist.")
                .foregroundColor(.secondary)

            Button("Choose CSV and Import") {
                importCSV()
            }
            
            if !previewRows.isEmpty {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Preview")
                        .font(.headline)

                    List(previewRows, id: \.self) { row in
                        HStack {
                            Text(row["Index"] ?? "")
                                .frame(width: 60, alignment: .leading)

                            Text(row["Type"] ?? "")
                                .frame(width: 120, alignment: .leading)

                            Text(row["Name"] ?? "")
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .frame(minHeight: 260)

                    Button("Import Previewed CSV") {
                        guard let ioLabels = pendingIOLabels else { return }

                        do {
                            try writeIOLabelsToPlist(ioLabels)
                            statusMessage = "CSV imported successfully."
                            previewRows = []
                            pendingIOLabels = nil
                        } catch {
                            statusMessage = "CSV import failed: \(error.localizedDescription)"
                        }
                    }
                    .keyboardShortcut(.defaultAction)
                }
            }

            Text(statusMessage)
                .foregroundColor(.secondary)

            Spacer()
        }
        .padding(30)
    }

    func importCSV() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.commaSeparatedText]

        if let folderURL = resolvedLastCSVFolderURL() {
            panel.directoryURL = folderURL
            print("CSV picker opening in:", folderURL.path)
        }

        if panel.runModal() == .OK, let url = panel.url {
            let chosenFolder = url.deletingLastPathComponent()
            saveLastCSVFolderBookmark(for: chosenFolder)
        
            do {
                let rows = try parseCSV(url: url)
                try validateCSVRows(rows)

                let ioLabels = buildIOLabels(from: rows)

                previewRows = rows
                pendingIOLabels = ioLabels

                statusMessage = "Preview ready (\(rows.count) rows)."
            } catch {
                statusMessage = "CSV import failed: \(error.localizedDescription)"
            }
        }
    }
    
    func parseCSV(url: URL) throws -> [[String: String]] {
        let content = try String(contentsOf: url, encoding: .utf8)
        let rows = content.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }

        guard let headerRow = rows.first else { return [] }
        let headers = headerRow.components(separatedBy: ",")

        var result: [[String: String]] = []

        for row in rows.dropFirst() {
            let values = row.components(separatedBy: ",")
            var dict: [String: String] = [:]

            for (index, header) in headers.enumerated() {
                if index < values.count {
                    dict[cleanCSVValue(header)] = cleanCSVValue(values[index])
                }
            }

            result.append(dict)
        }
        return result
    }
    
    func cleanCSVValue(_ value: String) -> String {
        var v = value.trimmingCharacters(in: .whitespacesAndNewlines)
        if v.hasPrefix("\"") && v.hasSuffix("\"") && v.count >= 2 {
            v.removeFirst()
            v.removeLast()
        }
        v = v.replacingOccurrences(of: "\"\"", with: "\"")
        return v
    }
    
    func validateCSVRows(_ rows: [[String: String]]) throws {
        guard let first = rows.first else {
            throw NSError(domain: "CSVImport", code: 1, userInfo: [NSLocalizedDescriptionKey: "CSV is empty."])
        }

        for key in ["Index", "Type", "Name"] {
            if first[key] == nil {
                throw NSError(domain: "CSVImport", code: 2, userInfo: [NSLocalizedDescriptionKey: "Missing CSV column: \(key)"])
            }
        }

        let allowedTypes = ["Mono Input", "Stereo Input", "Mono Output", "Stereo Output", "Bus"]

        for row in rows {
            let type = (row["Type"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if !allowedTypes.contains(type) {
                throw NSError(domain: "CSVImport", code: 3, userInfo: [NSLocalizedDescriptionKey: "Invalid Type value: \(type)"])
            }
        }
    }
    
    func buildIOLabels(from rows: [[String: String]]) -> [String: Any] {

        var result: [String: Any] = [:]
        var dev: [String: Any] = [:]

        for row in rows {
            guard
                let typeDisplay = row["Type"],
                let rawType = rawTypeName(for: typeDisplay),
                let indexStr = row["Index"]
            else { continue }

            let name = row["Name"] ?? ""
            let index = indexStr

            // opt rule
            let optValue: Int = name.trimmingCharacters(in: .whitespaces).isEmpty ? 1 : 4

            // get or create type dict
            var typeDict = dev[rawType] as? [String: Any] ?? [:]

            // build entry
            var entry: [String: Any] = [:]

            if !name.isEmpty {
                entry["lname"] = name
            }

            entry["opt"] = optValue

            typeDict[index] = entry
            dev[rawType] = typeDict
        }

        result["dev_1"] = dev

        return result
    }
    
    func writeIOLabelsToPlist(_ ioLabels: [String: Any]) throws {
        let plistURL = URL(fileURLWithPath: (plistPath as NSString).expandingTildeInPath)

        let currentData = try Data(contentsOf: plistURL)
        guard var currentPlist = try PropertyListSerialization.propertyList(from: currentData, format: nil) as? [String: Any] else {
            throw NSError(domain: "CSVImport", code: 10, userInfo: [NSLocalizedDescriptionKey: "Current plist is invalid."])
        }

        currentPlist["IOLabels"] = [ioLabels]

        let newData = try PropertyListSerialization.data(fromPropertyList: currentPlist, format: .xml, options: 0)
        try newData.write(to: plistURL, options: .atomic)
    }
    
    func resolvedLastCSVFolderURL() -> URL? {
        guard !lastCSVFolderBookmark.isEmpty else { return nil }

        do {
            var isStale = false
            let url = try URL(
                resolvingBookmarkData: lastCSVFolderBookmark,
                options: [.withSecurityScope],
                relativeTo: nil,
                bookmarkDataIsStale: &isStale
            )

            if isStale {
                let newBookmark = try url.bookmarkData(
                    options: [.withSecurityScope],
                    includingResourceValuesForKeys: nil,
                    relativeTo: nil
                )
                lastCSVFolderBookmark = newBookmark
            }

            return url
        } catch {
            print("Failed to resolve CSV folder bookmark:", error)
            return nil
        }
    }
    
    func saveLastCSVFolderBookmark(for folderURL: URL) {
        do {
            let bookmark = try folderURL.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            lastCSVFolderBookmark = bookmark
            print("Saved CSV folder bookmark:", folderURL.path)
        } catch {
            print("Failed to save CSV folder bookmark:", error)
        }
    }
}
