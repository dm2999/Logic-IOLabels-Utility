//
//  Logic_IOLabels_UtilityApp.swift
//  Logic IOLabels Utility
//
//  Created by Djordjo Micic on 23.03.26.
//

import SwiftUI

@main
struct Logic_IOLabels_UtilityApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
